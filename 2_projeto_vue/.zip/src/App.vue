<template>
    <div>
        <primeiro-componente/>
        <p>{{ testando }}</p>
        <hr>
        <LifeCycle/>
        <pessoa/>
    </div>
</template>

<script>
    import PrimeiroComponente from './components/primeiroComponente.vue'
    import LifeCycle from './components/LifeCycle.vue'
    import Pessoa from './components/Pessoa.vue'

    export default {
        name: 'App',
        components: {
            PrimeiroComponente,
            LifeCycle,
                Pessoa
        },
        data() {
            return {
                testando: "Teste"
            }
        }
    }
</script>