<template>
    <div>
        <h1>LifeCycle Hooks</h1>
        <h2>Meu nome é: {{ nome }}</h2>
    </div>
</template>

<script>
    export default {
        name: 'LifeCycle',
        data() {
            return {
                nome: "Ainda não sei"
            }
        },
        created() {
            setTimeout (() => {  
                this.nome = "Matheus"
            }, 1000)
        } ,
        mounted() {
            setTimeout (() => {
                this.nome = "Pedro"
            }, 2000)
        }
    }
</script>

