<template>
    <div>
        <hr>
        <h2>Esta é da descrição da pessoa: {{ nome }}</h2>
        <p>Estou trabalhando no momento</p>
        <p>Uso as seguintes tecnologias</p>
        <ul>
            <li>JavaScript</li>
            <li>PHP</li>
            <li>Python</li>
        </ul>
    </div>
</template>

<script>
    export default {
        name: 'Info'
    }
</script>