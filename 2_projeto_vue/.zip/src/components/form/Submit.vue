<template>
    <input type="submit" value="Enviar">
</template>

<script>
    export default {
        name: 'Submit',
    }
</script>