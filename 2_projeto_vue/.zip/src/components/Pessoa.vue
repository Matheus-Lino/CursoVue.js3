<template>
    <div>
        <Info/>
    </div>
</template>

<script>
import Info from './Info'

    export default {
        name: 'Pessoa',
        components: {
            Info
        },
        data() {
            return {
                nome: "Matheus"
            }
        }
    }
</script>