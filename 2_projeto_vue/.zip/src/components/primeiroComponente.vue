<template>
   <div>
    <h1>Componentes</h1>
    <p>Meu nome é {{nome}} e minha profissao é {{profissao}}</p>
    <hr>
   </div>
</template>

<script>
    export default {
        name: 'PrimeiroComponente',
        data() {
            return {
                nome: "Matheus",
                profissao: "Programador"
            }
        }
    }
</script>